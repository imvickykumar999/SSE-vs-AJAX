from django.apps import AppConfig


class SseAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sse_app'
